#import <Foundation/Foundation.h>
@interface PodsDummy_RCTTypeSafety : NSObject
@end
@implementation PodsDummy_RCTTypeSafety
@end
