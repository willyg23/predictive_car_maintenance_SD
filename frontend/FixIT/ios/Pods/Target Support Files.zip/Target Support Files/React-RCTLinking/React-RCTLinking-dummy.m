#import <Foundation/Foundation.h>
@interface PodsDummy_React_RCTLinking : NSObject
@end
@implementation PodsDummy_React_RCTLinking
@end
