#import <Foundation/Foundation.h>
@interface PodsDummy_React_logger : NSObject
@end
@implementation PodsDummy_React_logger
@end
