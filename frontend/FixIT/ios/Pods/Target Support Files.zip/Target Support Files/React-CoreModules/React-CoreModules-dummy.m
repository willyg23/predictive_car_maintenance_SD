#import <Foundation/Foundation.h>
@interface PodsDummy_React_CoreModules : NSObject
@end
@implementation PodsDummy_React_CoreModules
@end
