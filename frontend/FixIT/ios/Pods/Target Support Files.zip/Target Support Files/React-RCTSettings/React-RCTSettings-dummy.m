#import <Foundation/Foundation.h>
@interface PodsDummy_React_RCTSettings : NSObject
@end
@implementation PodsDummy_React_RCTSettings
@end
