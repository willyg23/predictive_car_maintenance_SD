#import <Foundation/Foundation.h>
@interface PodsDummy_glog : NSObject
@end
@implementation PodsDummy_glog
@end
