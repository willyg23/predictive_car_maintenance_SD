#import <Foundation/Foundation.h>
@interface PodsDummy_React_RCTFabric : NSObject
@end
@implementation PodsDummy_React_RCTFabric
@end
