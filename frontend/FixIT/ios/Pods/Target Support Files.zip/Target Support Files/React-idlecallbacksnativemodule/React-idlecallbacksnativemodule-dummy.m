#import <Foundation/Foundation.h>
@interface PodsDummy_React_idlecallbacksnativemodule : NSObject
@end
@implementation PodsDummy_React_idlecallbacksnativemodule
@end
