#import <Foundation/Foundation.h>
@interface PodsDummy_React_RCTAnimation : NSObject
@end
@implementation PodsDummy_React_RCTAnimation
@end
