#import <Foundation/Foundation.h>
@interface PodsDummy_RCTDeprecation : NSObject
@end
@implementation PodsDummy_RCTDeprecation
@end
