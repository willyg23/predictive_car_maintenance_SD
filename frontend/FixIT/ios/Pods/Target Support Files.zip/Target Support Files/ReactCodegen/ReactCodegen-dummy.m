#import <Foundation/Foundation.h>
@interface PodsDummy_ReactCodegen : NSObject
@end
@implementation PodsDummy_ReactCodegen
@end
