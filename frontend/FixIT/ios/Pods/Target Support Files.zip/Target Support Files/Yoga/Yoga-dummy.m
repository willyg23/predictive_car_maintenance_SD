#import <Foundation/Foundation.h>
@interface PodsDummy_Yoga : NSObject
@end
@implementation PodsDummy_Yoga
@end
