#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_FixIT_FixITTests : NSObject
@end
@implementation PodsDummy_Pods_FixIT_FixITTests
@end
