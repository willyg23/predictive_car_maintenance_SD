#import <Foundation/Foundation.h>
@interface PodsDummy_React_RCTVibration : NSObject
@end
@implementation PodsDummy_React_RCTVibration
@end
