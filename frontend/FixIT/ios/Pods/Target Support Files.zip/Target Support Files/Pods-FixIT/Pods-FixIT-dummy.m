#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_FixIT : NSObject
@end
@implementation PodsDummy_Pods_FixIT
@end
