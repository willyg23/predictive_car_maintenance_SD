#import <Foundation/Foundation.h>
@interface PodsDummy_React_perflogger : NSObject
@end
@implementation PodsDummy_React_perflogger
@end
